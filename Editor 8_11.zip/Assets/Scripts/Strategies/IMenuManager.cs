public interface IMenuManager
{
    void LoadScene(string sceneName);
    void ExitGame();
}

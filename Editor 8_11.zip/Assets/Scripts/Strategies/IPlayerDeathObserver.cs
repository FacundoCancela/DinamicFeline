public interface IPlayerDeathObserver
{
    void OnPlayerDeath();
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CharacterStats : MonoBehaviour
{
    public Stats stats; // Referencia al Scriptable Object de estad�sticas.
    private List<IPlayerDeathObserver> playerDeathObservers = new List<IPlayerDeathObserver>();
    public Slider slider;

    public int CurrentHealth => currentHealth;
    private int currentHealth; // La salud actual del personaje.
    private int damage;
    private float speed;

    private SpriteRenderer spriteRenderer; // Referencia al componente SpriteRenderer del hijo.
    private Color originalColor; // Almacena el color original del sprite.

    Animator animator;
    AudioSource audioSource;
    private void Start()
    {
        // Obt�n la referencia al componente SpriteRenderer del hijo.
        spriteRenderer = GetComponentInChildren<SpriteRenderer>();
        animator = GetComponent<Animator>();
        audioSource = GetComponent<AudioSource>();

        // Almacena el color original del sprite.
        if (spriteRenderer != null)
        {
            originalColor = spriteRenderer.color;
        }

        UpdateStats();

        var playerDeathObserver = new PlayerDeathObserver();

        // Registrar el observador en CharacterStats
        RegisterPlayerDeathObserver(playerDeathObserver);
        SetHealthBar();
    }

    public void UpdateStats()
    {
        currentHealth = stats.health;
        damage = stats.damage;
        speed = stats.speed;
    }

    // M�todo para recibir da�o.
    public void TakeDamage(int damageAmount)
    {
        currentHealth -= damageAmount;
        if(slider) slider.value = currentHealth;
        if (CompareTag("Player"))
        {
            animator.SetTrigger("Damaged");
        }
        else
        {
            audioSource.Play();
        }

        if (currentHealth <= 0)
        {
            Die();
        }
        else
        {
            // Cambiar temporalmente el color del sprite a rojo.
            StartCoroutine(FlashSpriteColor(Color.red, 0.2f)); // Cambia el color a rojo durante 0.2 segundos.
        }

        // Mostrar la vida actual del personaje en el Debug.Log.
        Debug.Log(gameObject.name + " Vida Actual: " + currentHealth);
    }

    // Corutina para destellar el color del sprite.
    private IEnumerator FlashSpriteColor(Color flashColor, float duration)
    {
        if (spriteRenderer != null)
        {
            spriteRenderer.color = flashColor; // Cambiar el color del sprite a rojo.

            yield return new WaitForSeconds(duration); // Esperar la duraci�n especificada.

            // Restaurar el color original del sprite.
            spriteRenderer.color = originalColor;
        }
    }

    // M�todo para aplicar un power-up de vida.
    public void ApplyHealthPowerUp(int healthAmount)
    {
        currentHealth += healthAmount;
        if (slider) slider.value = currentHealth;
        // Asegurarse de que la salud no supere el l�mite m�ximo.
        currentHealth = Mathf.Min(currentHealth, stats.health);

    }

    // M�todo para aplicar un power-up de da�o.
    public void ApplyDamagePowerUp(int damageBoost)
    {
        damage += damageBoost;
    }

    // M�todo para aplicar un power-up de velocidad.
    public void ApplySpeedPowerUp(float speedBoost)
    {
        speed += speedBoost;
    }

    public int DoDamage()
    {
        return damage;
    }

    public float GetSpeed()
    {
        return speed;
    }

    public void RegisterPlayerDeathObserver(IPlayerDeathObserver observer)
    {
        playerDeathObservers.Add(observer);
    }

    private void Die()
    {
        if (gameObject.CompareTag("Player"))
        {
            foreach (var observer in playerDeathObservers)
            {
                observer.OnPlayerDeath();
            }
        }
        else
        {
            Debug.Log(gameObject.name + " ha muerto.");
            PointManager.Instance.AddPoints(10);
            Destroy(gameObject);
        }
    }

    void SetHealthBar()
    {
        if (!gameObject.CompareTag("Player"))
        {
            //Si el objeto no es el jugador destruir componente slider para que no tire errores por todos lados
            Destroy(slider);
        }

        else
        {
            slider.maxValue = currentHealth;
            slider.value = slider.maxValue;
        }
    }
}

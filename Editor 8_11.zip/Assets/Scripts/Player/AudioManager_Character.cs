using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager_Character : MonoBehaviour
{
    [SerializeField ]public AudioSource AS_basicAttack;
    [SerializeField] public AudioSource AS_specialAttack;

}


